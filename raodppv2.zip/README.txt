RAOD++ / iso-cost study — Overleaf submission package
=====================================================

Journal : Image and Vision Computing (Elsevier)
Issue   : special issue "VSI: VP-NAV"
Class   : Elsevier CAS, double column (cas-dc)

HOW TO USE
----------
Upload this zip to Overleaf ("New Project" -> "Upload Project").
Set the main document to main.tex and the compiler to pdfLaTeX.
Overleaf runs bibtex automatically; locally use:

    pdflatex main && bibtex main && pdflatex main && pdflatex main

WHAT IS HERE
------------
main.tex                 front matter, declarations, and \input of the sections
01_introduction.tex      \
07_related_work.tex       |
02_method.tex             |  section files, in the order main.tex inputs them
03_experimental_setup.tex |  (related work follows the introduction)
04_results.tex            |
05_discussion.tex         |
06_conclusion.tex        /
references.bib           41 entries; each note field records where it was checked
fig/                     16 figures, all generated from output/runs.csv and figdata
cas-dc.cls               \
cas-common.sty            |  Elsevier CAS bundle, unmodified
cas-model2-names.bst      |
thumbnails/              /   icons the class uses in the front matter

BEFORE SUBMITTING — fields left blank on purpose
------------------------------------------------
main.tex contains four placeholders marked TO BE FILLED:

  * \ead{}          author email
  * orcid=          author ORCID
  * \affiliation{}  address line and postcode
  * three declaration sections at the end: competing interests, data
    availability, and use of generative AI

The AI declaration matters for this manuscript and should be written
deliberately rather than copied from a template.

NOTES ON THE BUILD
------------------
Wide tables and figures use the starred environments (table*, figure*) because
the double-column measure cannot hold them.

One overfull box of 123.6pt is reported at \maketitle. It comes from the class,
not from this manuscript: compiling Elsevier's own cas-dc-sample.tex produces the
same box at the same size, along with seven others.

A single-column draft can be produced by changing cas-dc to cas-sc in the
\documentclass line; the starred environments degrade gracefully.
